// Run: node inspect-cc-fulfillment.js --so=SO-2026-1003
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { getOrderLifecycle } = require('./cc-fulfillment-api');
const so = process.argv.find(arg => arg.startsWith('--so='))?.slice(5);
if (!so) { console.error('Usage: node inspect-cc-fulfillment.js --so=SO-2026-1003'); process.exit(1); }
(async () => {
  const input = path.join(__dirname, 'output', 'create-so-result.json');
  const results = JSON.parse(fs.readFileSync(input, 'utf8'));
  const entry = results.find(row => row.soNumber === so);
  if (!entry || entry.netsuite?.status !== 'ok' || entry.cartoncloud?.status !== 'ok' || !entry.cartoncloud.ccId) {
    throw new Error(`No successful NetSuite/CartonCloud order mapping for ${so}`);
  }
  const order = await getOrderLifecycle(entry.cartoncloud.ccId);
  if (order.id && order.id !== entry.cartoncloud.ccId) throw new Error('CartonCloud order ID mismatch');
  if (order.references?.customer && order.references.customer !== so) throw new Error('CartonCloud SO reference mismatch');
  const report = { soNumber: so, ccId: entry.cartoncloud.ccId, status: order.status,
    lifecycleState: order.lifecycleState || null, items: order.items || null, order };
  const output = path.join(__dirname, 'output', `cc-lifecycle-${so.replace(/[^a-z0-9_-]/gi, '_')}.json`);
  fs.writeFileSync(output, JSON.stringify(report, null, 2));
  console.log(`SO: ${so}\nCC UUID: ${entry.cartoncloud.ccId}\nStatus: ${order.status}`);
  console.log('Available lifecycle actions:', JSON.stringify(order.lifecycleState?.actions || {}, null, 2));
  console.log(`Full response saved to ${output}`);
  console.log('READ-ONLY: No inventory or order status changes performed.');
})().catch(err => {
  console.error('CartonCloud inspection failed:', err.response?.status || '', JSON.stringify(err.response?.data || err.message));
  process.exitCode = 1;
});
